window.onload = function() {
  showSlides();

  let noti = document.querySelector('#noti');
  let gallery = document.querySelector('#gallery');
  noti.onclick = function() {
    noti.classList.add("active");
    gallery.classList.remove("active");
  }
  gallery.onclick = function() {
    noti.classList.remove("active");
    gallery.classList.add("active");
  }

    let modal = document.querySelector('#modalWrap');
    let notice = document.querySelector('.notice > ul > li:first-child');
    let btn = document.querySelector('.btn');
    notice.onclick = function() {
            modal.classList.add("active");
        }
    btn.onclick = function () {
        modal.classList.remove("active");
    }
}

function showSlides() {
  let current = 1;
  let imgSlide = document.querySelector('.imgSlide');
  let images = imgSlide.getElementsByTagName('a');
  setInterval(() => {
    for(i=0; i<images.length; i++) {
      images[i].style.opacity = 0;
    }
    images[current-1].style.opacity = 1;
    current++;
    if(current > images.length)
    current = 1;
  }, 2000);
}